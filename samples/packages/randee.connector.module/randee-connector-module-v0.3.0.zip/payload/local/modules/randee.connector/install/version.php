<?php
$arModuleVersion = [
    'VERSION' => '0.3.0',
    'VERSION_DATE' => '2026-05-24 00:00:00',
];
